package com.example.magic8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
