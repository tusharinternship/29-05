package com.example.emailpassword

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
