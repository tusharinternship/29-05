package com.example.autheticationscreen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
