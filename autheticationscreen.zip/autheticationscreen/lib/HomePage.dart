import 'package:flutter/material.dart';

class SecondPage extends StatelessWidget {
  const SecondPage({Key? key, required this.title}) : super(key: key);
  final String title;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Column(children: [
        TextButton(
          onPressed: () {
            Navigator.pushNamed(context, '/b');
          },
          child: const Text('MARK ATTENDANCE'),
        ),
        TextButton(
          onPressed: () {
            Navigator.pushNamed(context, '/b');
            ;
          },
          child: const Text('APPLY FOR LEAVE'),
        )
      ]),
    );
  }
}
